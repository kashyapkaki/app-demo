let personalData = {};

function loadData() {
  document.getElementById("button1").addEventListener("click", function () {
    document.getElementById("animals").style.textDecoration =
      document.getElementById("animals").style.textDecoration == ""
        ? "underline"
        : "";
    document.getElementById("animals").style.fontStyle =
      document.getElementById("animals").style.fontStyle == "" ? "italic" : "";
  });
  document.getElementById("button2").addEventListener("click", function () {
    const mammals = document.querySelectorAll(".mammal");
    mammals.forEach((box) => {
      box.style.border = box.style.border == "" ? "2px solid dimgray" : "";
      box.style.borderRadius = box.style.borderRadius == "" ? "10px" : "";
    });
  });
  document.getElementById("button3").addEventListener("click", function () {
    const birds = document.querySelectorAll(".bird");
    birds.forEach((box) => {
      box.style.backgroundColor =
        box.style.backgroundColor == "" ? "black" : "";
      box.style.borderRadius = box.style.borderRadius == "" ? "10px" : "";
    });
  });
  fetch("./data/a1.json")
    .then((res) => res.json())
    .then((dataJSON) => {
      console.log(dataJSON);
      personalData = dataJSON.student;
      localStorage.setItem("personalData", JSON.stringify(personalData));
      let headerText = `Fall 2022 Assignment #1 for <a href="./pages/page2.html">${personalData.name}</a> from ${personalData.homeCountry}`;
      document.querySelector("header").innerHTML = headerText;
      let footerText = `My Login: ${personalData.login} / My ID: ${personalData.studentId} / My Program: ${personalData.program}`;
      document.querySelector("footer").innerHTML = footerText;
      let animalHTML = ``;
      for (const iterator of dataJSON.animals) {
        let animalParagraph = `<p class="animal classification ${iterator.classification.toLowerCase()}">${
          iterator.id
        }/${iterator.name}/${iterator.classification}</p>`;
        animalHTML += animalParagraph;
      }
      document.getElementById("animals").innerHTML = animalHTML;
    });
}
