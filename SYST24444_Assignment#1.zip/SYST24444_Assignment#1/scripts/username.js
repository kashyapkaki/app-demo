let data = {};

function initialLoad() {
  data.city = document.getElementById("cities").value;
  let headerText = `Fall 2022 Assignment #1 for Your Full Name from Your Home Country`;
  document.querySelector("header").innerHTML = headerText;

  let footerText = `My Login: Your Login Name / My ID: Your ID / My Program: Your Program`;
  document.querySelector("footer").innerHTML = footerText;

  dropdownChange();
  document
    .getElementById("cities")
    .addEventListener("change", function (event) {
      data.city = event.target.value;
      dropdownChange();
    });
  document
    .getElementById("tickets")
    .addEventListener("change", function (event) {
      if (parseInt(event.target.value) < 0) {
        document.querySelectorAll(".ticketsamount").forEach(function (element) {
          element.style.backgroundColor = "red";
          document.getElementById("total").value = 12.99 * 0;
        });
      } else {
        document.querySelectorAll(".ticketsamount").forEach(function (element) {
          element.style.backgroundColor = "";
          document.getElementById("total").value =
            12.99 * parseInt(event.target.value);
        });
      }
    });

  let date = document.getElementById("date");
  date.min = new Date().toISOString().split("T")[0];
  for (const iterator of document.getElementsByClassName("time")) {
    iterator.style.backgroundColor = "";
    iterator.addEventListener("click", function (event) {
      for (const element of document.getElementsByClassName("time")) {
        element.style.backgroundColor = "";
      }
      event.target.style.backgroundColor = "lightgreen";
      console.log(event.target.textContent);
    });
  }

  document.querySelector("#age").addEventListener("change", function (event) {
    if (parseInt(event.target.value) < 20) {
      event.target.style.backgroundColor = "red";
    } else {
      event.target.style.backgroundColor = "";
    }
  });

  document.getElementById("submit").addEventListener("click", function () {});
}

function dropdownChange() {
  document.getElementById("toronto_div").style.display =
    document.getElementById("cities").value === "toronto" ? "block" : "none";
  document.getElementById("vancouver_div").style.display =
    document.getElementById("cities").value === "vancouver" ? "block" : "none";
  document.getElementById("ottawa_div").style.display =
    document.getElementById("cities").value === "ottawa" ? "block" : "none";
}
