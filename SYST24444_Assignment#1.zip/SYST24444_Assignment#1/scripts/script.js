let data = {};

function onload() {
  data = JSON.parse(localStorage.getItem("personalData"));
  console.log(data);

  let h1 = document.createElement("h1");
  h1.textContent = `My name is ${data.name}`;
  h1.style.color = "red";

  let h2 = document.createElement("h2");
  h2.textContent = `My student Id is ${data.studentId}`;
  h2.style.color = "darkred";

  let h3 = document.createElement("h3");
  h3.textContent = `My login name is ${data.login}`;
  h3.style.color = "indianred";

  let h4 = document.createElement("h4");
  h4.textContent = `My program name is ${data.program}`;
  h4.style.color = "palevioletred";

  let h5 = document.createElement("h5");
  h5.textContent = `My home country is ${data.homeCountry}`;
  h5.style.color = "indigo";

  let img = document.createElement("img");
  img.src = `../images/profile.png`;
  img.height = "50";
  img.width = "50";

  document.getElementById("personalInfo").appendChild(h1);
  document.getElementById("personalInfo").appendChild(h2);
  document.getElementById("personalInfo").appendChild(h3);
  document.getElementById("personalInfo").appendChild(h4);
  document.getElementById("personalInfo").appendChild(h5);
  document.getElementById("personalInfo").appendChild(img);
}
