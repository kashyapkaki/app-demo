function onload() {
  let br = document.createElement("br");

  let first = document.createElement("label");
  first.textContent = `Firstname : ${localStorage.getItem("first")}`;

  first.appendChild(br);

  let last = document.createElement("label");
  last.textContent = `Lastname : ${localStorage.getItem("last")}`;

  let br1 = document.createElement("br");
  last.appendChild(br1);

  let city = document.createElement("label");
  city.textContent = `City : ${localStorage.getItem("city")}`;

  let br2 = document.createElement("br");
  city.appendChild(br2);

  let age = document.createElement("label");
  age.textContent = `Age : ${localStorage.getItem("age")}`;

  document.getElementById("info").appendChild(first);
  document.getElementById("info").appendChild(last);
  document.getElementById("info").appendChild(city);
  document.getElementById("info").appendChild(age);
}
